{{-- footer --}}
<footer>
    <div class="global-footer">
        <div class="footer-first">
            <div class="logo">
                <p>F</p>
                <p>O</p>
                <p>R</p>
                <p>E</p>
                <p>V</p>
                <p>E</p>
                <p>R</p>
            </div>
            <div class="infomation">
                <p><i class="fa-solid fa-location-dot"></i> Thủ Đức, Hồ Chí Minh</p>
                <p><i class="fa-solid fa-phone"></i> 023-5664-468</p>
                <p><i class="fa-solid fa-envelope"></i> admin@admin.com</p>
            </div>
            <div class="store-active">
                <p>Giờ hoạt động: 6AM - 22PM</p>
            </div>
            <div class="contact">
              
            </div>
        </div>
        <div class="footer-second">

            <h3>Copyright © 2024 aloeveravn.com. All Rights Reserved.</h3>
        </div>
    </div>
</footer>
{{-- end footer --}}