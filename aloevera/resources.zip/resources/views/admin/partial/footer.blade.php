    <!--begin::Footer-->
    <footer class="app-footer"> <!--begin::To the end-->
       
    </footer> <!--end::Footer-->